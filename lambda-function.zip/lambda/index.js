const https = require('https');
const AWS = require('aws-sdk');

// S3クライアントの初期化
const s3 = new AWS.S3({ region: process.env.REGION });

exports.handler = async (event) => {
    console.log('Event received:', JSON.stringify(event, null, 2));
    
    try {
        if (!event.Records || !event.Records[0] || !event.Records[0].Sns) {
            console.error('Invalid event structure:', JSON.stringify(event));
            return {
                statusCode: 400,
                body: 'Invalid event structure'
            };
        }

        // SNSメッセージを解析
        const snsMessage = event.Records[0].Sns;
        const messageStr = snsMessage.Message;
        const subject = snsMessage.Subject || 'CI/CD Pipeline Notification';
        
        console.log('SNS Message:', messageStr);
        console.log('Subject:', subject);
        
        let parsedMessage;
        try {
            // JSONの場合はパース
            parsedMessage = JSON.parse(messageStr);
        } catch (e) {
            // テキストメッセージの場合はそのまま使用
            parsedMessage = messageStr;
        }
        
        const messageText = typeof parsedMessage === 'object' 
            ? JSON.stringify(parsedMessage, null, 2) 
            : parsedMessage;
        
        let color = '#36a64f'; // デフォルトは緑色
        const messageContent = messageText.toLowerCase();
        if (messageContent.includes('failed') || messageContent.includes('failure') || messageContent.includes('失敗')) {
            color = '#ff0000'; // 失敗は赤色
        } else if (messageContent.includes('started') || messageContent.includes('in progress') || messageContent.includes('開始')) {
            color = '#ffcc00'; // 開始は黄色
        }
        
        // テスト完了の通知の場合、S3からテスト結果のURLを取得
        let testReportText = '';
        if ((messageContent.includes('succeeded') || messageContent.includes('failed')) && 
            (subject.includes('Test') || subject.includes('test') || messageContent.includes('test'))) {
            try {
                const reportUrl = await getLatestTestReportUrl();
                if (reportUrl) {
                    testReportText = `\n\n*テスト結果レポート*: <${reportUrl}|ここをクリックして確認する>`;
                }
            } catch (error) {
                console.error('テストレポートURL取得エラー:', error);
            }
        }
        
        // Slackメッセージを構築
        const slackMessage = {
            text: `*${subject}*`,
            attachments: [{
                color: color,
                text: messageText + testReportText,
                footer: 'AWS CodePipeline Notification',
                ts: Math.floor(Date.now() / 1000)
            }]
        };
        
        console.log('Slack message:', JSON.stringify(slackMessage));
        
        // Slackに送信
        const webhookUrl = process.env.SLACK_WEBHOOK_URL;
        if (!webhookUrl) {
            throw new Error('SLACK_WEBHOOK_URL環境変数が設定されていません');
        }
        
        const parsedUrl = new URL(webhookUrl);
        const options = {
            hostname: parsedUrl.hostname,
            path: parsedUrl.pathname + parsedUrl.search,
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        };
        
        const response = await sendToSlack(options, slackMessage);
        console.log('Slack response:', response);
        
        return {
            statusCode: 200,
            body: 'Message sent to Slack successfully'
        };
    } catch (error) {
        console.error('Error processing message:', error);
        return {
            statusCode: 500,
            body: `Error: ${error.message}`
        };
    }
};

// S3から最新のテストレポートのURLを取得する関数
async function getLatestTestReportUrl() {
    try {
        const bucketName = process.env.PLAYWRIGHT_REPORTS_BUCKET;
        if (!bucketName) {
            throw new Error('PLAYWRIGHT_REPORTS_BUCKET環境変数が設定されていません');
        }
        
        // S3バケットの最新のオブジェクトを取得
        const params = {
            Bucket: bucketName,
            Prefix: 'report-',  // テストレポートのプレフィックスがあれば指定
            MaxKeys: 10
        };
        
        const data = await s3.listObjectsV2(params).promise();
        if (!data.Contents || data.Contents.length === 0) {
            console.log('テストレポートが見つかりませんでした');
            return null;
        }
        
        // 最新のフォルダを特定（LastModifiedで並べ替え）
        const latestObject = data.Contents.sort((a, b) => 
            new Date(b.LastModified) - new Date(a.LastModified)
        )[0];
        
        // index.htmlへのパスを構築
        let reportPath;
        if (latestObject.Key.endsWith('/')) {
            reportPath = `${latestObject.Key}index.html`;
        } else if (latestObject.Key.endsWith('index.html')) {
            reportPath = latestObject.Key;
        } else {
            // ディレクトリの場合はindex.htmlを追加、そうでない場合はそのまま
            reportPath = latestObject.Key.includes('/') && !latestObject.Key.endsWith('/') 
                ? latestObject.Key 
                : `${latestObject.Key}/index.html`;
        }
        
        // S3ウェブサイトエンドポイントURL
        const websiteUrl = `https://${bucketName}.s3-website-${process.env.REGION}.amazonaws.com/${reportPath}`;
        console.log('テストレポートURL:', websiteUrl);
        
        return websiteUrl;
    } catch (error) {
        console.error('S3レポート取得エラー:', error);
        return null;
    }
}

function sendToSlack(options, message) {
    return new Promise((resolve, reject) => {
        const req = https.request(options, (res) => {
            let responseBody = '';
            res.on('data', (chunk) => {
                responseBody += chunk;
            });
            res.on('end', () => {
                if (res.statusCode >= 200 && res.statusCode < 300) {
                    resolve({
                        statusCode: res.statusCode,
                        body: responseBody
                    });
                } else {
                    console.error(`Slack返答エラー: ${res.statusCode} ${responseBody}`);
                    reject(new Error(`Slack API returned status code ${res.statusCode}: ${responseBody}`));
                }
            });
        });
        
        req.on('error', (err) => {
            console.error('Slackへの送信エラー:', err);
            reject(err);
        });
        
        req.write(JSON.stringify(message));
        req.end();
    });
}
